package com.example.isaachernandezquinonez.week3.vistaFragment;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.isaachernandezquinonez.week3.R;
import com.example.isaachernandezquinonez.week3.adapter.AdatperInstagramprofile;
import com.example.isaachernandezquinonez.week3.adapter.MascotaAdaptador;
import com.example.isaachernandezquinonez.week3.pojo.Mascota;
import com.example.isaachernandezquinonez.week3.presentador.IRecyclerViewFragmentPresenter;
import com.example.isaachernandezquinonez.week3.presentador.RecylerViewFragmentPresenter;

import java.util.ArrayList;


public class FragmentListMascotas extends Fragment implements IRecyclerViewFragmentView{
    private RecyclerView listMascotas;
    ArrayList<Mascota> mascotas;
    public IRecyclerViewFragmentPresenter presenter;

    public FragmentListMascotas(){

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_fragment_list_mascotas,container,false);
        listMascotas = (RecyclerView) v.findViewById(R.id.rvMascotas);
        presenter = new RecylerViewFragmentPresenter(this,getContext());
        FloatingActionButton FbButton =( FloatingActionButton) v.findViewById(R.id.fabButton);
        FbButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(),"Floating Action Button",Toast.LENGTH_SHORT).show();
            }
        });

        return v;
    }


    @Override
    public void generarLinearLayoutVertical() {
        LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        listMascotas.setLayoutManager(llm);
    }

    @Override
    public MascotaAdaptador crearAdaptador(ArrayList<Mascota> mascotas) {
        MascotaAdaptador adaptador = new MascotaAdaptador(mascotas,getActivity());
        return adaptador;
    }


    public void inicializarAdaptadorRV(MascotaAdaptador adaptador) {
        listMascotas.setAdapter(adaptador);
    }


    public void generaGridLayout() {

    }

    public void initMascotas(){
        mascotas = new ArrayList<Mascota>();
        mascotas.add(new Mascota(1,"Chester",R.drawable.cat,1));
        mascotas.add(new Mascota(1,"Daysi",R.drawable.clown_fish,3));
        mascotas.add(new Mascota(1,"Perry",R.drawable.cow,4));
        mascotas.add(new Mascota(1,"Bestia",R.drawable.duck,4));
        mascotas.add(new Mascota(1,"Corsar",R.drawable.frog,7));
        mascotas.add(new Mascota(1,"Zu",R.drawable.giraffe,8));
        mascotas.add(new Mascota(1,"Zuri",R.drawable.lion,2));
        mascotas.add(new Mascota(1,"Monster",R.drawable.penguin,3));
        mascotas.add(new Mascota(1,"Terry",R.drawable.pig,3));
        mascotas.add(new Mascota(1,"Pinky",R.drawable.toucan,2));
    }

}
