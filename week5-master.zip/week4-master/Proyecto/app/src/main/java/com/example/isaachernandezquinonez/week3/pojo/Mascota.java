package com.example.isaachernandezquinonez.week3.pojo;

/**
 * Created by isaachernandezquinonez on 24/06/16.
 */
public class Mascota {
    private int id;
    private String nombreMascota;
    private int fotoMascota;
    private int likes;

    public Mascota(int id, String nombreMascota, int fotoMascota, int likes) {
        this.id = id;
        this.nombreMascota = nombreMascota;
        this.fotoMascota = fotoMascota;
        this.likes = likes;
    }

    public Mascota() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombreMascota() {
        return nombreMascota;
    }

    public void setNombreMascota(String nombreMascota) {
        this.nombreMascota = nombreMascota;
    }

    public int getFotoMascota() {
        return fotoMascota;
    }

    public void setFotoMascota(int fotoMascota) {
        this.fotoMascota = fotoMascota;
    }

    public int getLikes() {
        return likes;
    }

    public void setLikes(int likes) {
        this.likes = likes;
    }
/*/
    public void addLikes(){
        int NolikesIncrement;
        NolikesIncrement = Integer.parseInt(NoLikes);
        NolikesIncrement++;
        this.NoLikes = String.valueOf(NolikesIncrement);
    }
*/
}
