package com.example.isaachernandezquinonez.week3.presentador;

/**
 * Created by isaachernandezquinonez on 28/06/16.
 */
public interface IRecyclerViewFragmentPresenter {
    public void obtenerMascotasBaseDatos();
    public void mostrarMascotasRV();
}
