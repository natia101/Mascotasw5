package com.example.isaachernandezquinonez.week3.presentador;

import android.content.Context;

import com.example.isaachernandezquinonez.week3.adapter.MascotaAdaptador;
import com.example.isaachernandezquinonez.week3.db.ConstructorMascotas;
import com.example.isaachernandezquinonez.week3.pojo.Mascota;
import com.example.isaachernandezquinonez.week3.vistaFragment.IRecyclerViewFragmentView;

import java.util.ArrayList;

/**
 * Created by isaachernandezquinonez on 28/06/16.
 */
public class RecylerViewFragmentPresenter implements IRecyclerViewFragmentPresenter{
    private IRecyclerViewFragmentView iRecyclerViewFragmentView;
    private Context context;
    private ConstructorMascotas constructorMascotas;
    private ArrayList<Mascota> mascotas;

    public RecylerViewFragmentPresenter(IRecyclerViewFragmentView iRecyclerViewFragmentView, Context context){
        this.iRecyclerViewFragmentView = iRecyclerViewFragmentView;
        this.context = context;
        obtenerMascotasBaseDatos();
    }

    @Override
    public void obtenerMascotasBaseDatos() {
        constructorMascotas = new ConstructorMascotas(context);
        mascotas = constructorMascotas.obtenerDatos();
        mostrarMascotasRV();
    }

    @Override
    public void mostrarMascotasRV() {
        iRecyclerViewFragmentView.inicializarAdaptadorRV(iRecyclerViewFragmentView.crearAdaptador(mascotas));
        iRecyclerViewFragmentView.generarLinearLayoutVertical();
    }
}
