package com.example.isaachernandezquinonez.week3.vistaFragment;

import com.example.isaachernandezquinonez.week3.adapter.MascotaAdaptador;
import com.example.isaachernandezquinonez.week3.pojo.Mascota;

import java.util.ArrayList;

/**
 * Created by isaachernandezquinonez on 28/06/16.
 */
public interface IRecyclerViewFragmentView {
    public void generarLinearLayoutVertical();
    public MascotaAdaptador crearAdaptador(ArrayList<Mascota> mascotas);
    public void inicializarAdaptadorRV(MascotaAdaptador adaptador);

}
