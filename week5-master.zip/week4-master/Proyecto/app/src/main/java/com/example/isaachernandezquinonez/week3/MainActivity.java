package com.example.isaachernandezquinonez.week3;

import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.isaachernandezquinonez.week3.adapter.AdapterFragment;
import com.example.isaachernandezquinonez.week3.comunes.ContactoEmail;
import com.example.isaachernandezquinonez.week3.comunes.ProfileActivity;
import com.example.isaachernandezquinonez.week3.comunes.SegundaPantalla;
import com.example.isaachernandezquinonez.week3.vistaFragment.FragmentListMascotas;
import com.example.isaachernandezquinonez.week3.vistaFragment.Fragment_Type_Instagram;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity{

    private Toolbar toolbar;
    private TabLayout tabLayout;
    private ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*
        TextView toolbar_title = (TextView) findViewById(R.id.toolbar_title);
        toolbar_title.setText(R.string.txtMascotas);
        Toolbar miActionBar = (Toolbar) findViewById(R.id.miActionBar);
        setSupportActionBar(miActionBar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        */
        toolbar = (Toolbar) findViewById(R.id.toolbar);

        tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        viewPager = (ViewPager) findViewById(R.id.viewPager);

        // Validacion si toolbar es nulo y consiga setsupportActionBar
        if(toolbar != null){
            setSupportActionBar(toolbar);
        }
        TextView toolbar_title_standar = (TextView) findViewById(R.id.toolbar_titleMain);
        toolbar_title_standar.setText("Mascotas");
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        setUpViewPager();


    }
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_opciones, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()){
            case R.id.menuContacto:
                Toast.makeText(this,getResources().getString(R.string.txtContacto),Toast.LENGTH_SHORT).show();
                Intent intentContacto = new Intent(this,ContactoEmail.class);
                startActivity(intentContacto);
                break;
            case R.id.menuAcerca:
                Intent intentAcerca = new Intent(this,ProfileActivity.class);
                startActivity(intentAcerca);
                Toast.makeText(this,getString(R.string.txtAcerca),Toast.LENGTH_SHORT).show();
                break;
        }


        return super.onOptionsItemSelected(item);
    }


    public void getList(View v){
        Intent intent = new Intent(MainActivity.this,SegundaPantalla.class);
        startActivity(intent);
    }

    // con esto agregamos los fragments a nuestro arraylist
    private ArrayList<Fragment> agregarFragments(){
        ArrayList<Fragment> fragments = new ArrayList<>();
        fragments.add(new FragmentListMascotas());
        fragments.add(new Fragment_Type_Instagram());
        return fragments;
    }
    // este metodo pondra en orbita los fragments
    private void setUpViewPager(){
        viewPager.setAdapter(new AdapterFragment(getSupportFragmentManager(),agregarFragments()));
        // agregar al tablayout
        tabLayout.setupWithViewPager(viewPager);
        // Añadir un icono a nuestros fragments
        tabLayout.getTabAt(0).setIcon(R.drawable.note);
        tabLayout.getTabAt(1).setIcon(R.drawable.ic_action_name);
    }

}

