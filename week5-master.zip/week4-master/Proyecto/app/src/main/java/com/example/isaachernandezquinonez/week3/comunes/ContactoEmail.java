package com.example.isaachernandezquinonez.week3.comunes;

import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.creativityapps.gmailbackgroundlibrary.BackgroundMail;
import com.example.isaachernandezquinonez.week3.R;


public class ContactoEmail extends AppCompatActivity {
    private  TextView tietMensaje;
    private TextView tietEmail;
    private TextView tietNombre;
    private Button btnSendEmail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacto_email);
        TextView toolbar_title_standar = (TextView) findViewById(R.id.toolbar_title_standar);
        toolbar_title_standar.setText(R.string.txtContacto);
        Toolbar miActionBar_standar = (Toolbar) findViewById(R.id.miActionBar_standar);
        setSupportActionBar(miActionBar_standar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        tietMensaje = (TextView) findViewById(R.id.tietMensaje);
        tietEmail = (TextView) findViewById(R.id.tietEmail);
        tietNombre = (TextView) findViewById(R.id.tietNombre);
        btnSendEmail = (Button) findViewById(R.id.btnSendEmail);
        btnSendEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendEmail();
                Snackbar.make(v,"Email enviado con Exito",Snackbar.LENGTH_LONG).setAction("OK", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                    }
                }).setActionTextColor(getResources().getColor(R.color.colorFBButton)).show();
                tietNombre.setText("");
                tietEmail.setText("");
                tietMensaje.setText("");
            }
        });

    }
    private void sendEmail() {
        BackgroundMail.newBuilder(this)
                .withUsername("mnarinhernda@gmail.com")
                .withPassword("D3v3lop3r")
                .withMailto(tietEmail.getText().toString())
                .withSubject("Mensaje Enviado desde App")
                .withBody(tietMensaje.getText().toString()+ " Enviado por : "+ tietNombre.getText().toString())
                .send();

    }
}
