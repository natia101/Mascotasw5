package com.example.isaachernandezquinonez.week3.vistaFragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.isaachernandezquinonez.week3.R;
import com.example.isaachernandezquinonez.week3.adapter.AdatperInstagramprofile;
import com.example.isaachernandezquinonez.week3.pojo.Mascota;

import java.util.ArrayList;


public class Fragment_Type_Instagram extends Fragment {
    private RecyclerView listMascotas;
    ArrayList<Mascota> mascotas;
    public Fragment_Type_Instagram(){

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_fragment__type__instagram,container,false);
        listMascotas = (RecyclerView) v.findViewById(R.id.rvInstagramMascotas);
        GridLayoutManager glm = new GridLayoutManager(getActivity(),3);
        glm.setOrientation(LinearLayoutManager.VERTICAL);
        initMascotasCard();
        inicilizarAdaptador();


        listMascotas.setLayoutManager(glm);


        return v;
    }
    private void inicilizarAdaptador(){
        AdatperInstagramprofile adaptador = new AdatperInstagramprofile(mascotas,getActivity());
        listMascotas.setAdapter(adaptador);
    }

    public void initMascotasCard(){
        mascotas = new ArrayList<Mascota>();
        mascotas.add(new Mascota(1,"Chester",R.drawable.cat, 2));
        mascotas.add(new Mascota(1,"Daysi",R.drawable.clown_fish, 4 ));
        mascotas.add(new Mascota(1,"Perry",R.drawable.cow, 5 ));
        mascotas.add(new Mascota(1,"Bestia",R.drawable.duck, 6 ));
        mascotas.add(new Mascota(1,"Corsar",R.drawable.frog, 8 ));

    }

}
