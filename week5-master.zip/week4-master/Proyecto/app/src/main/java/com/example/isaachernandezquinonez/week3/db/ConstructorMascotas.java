package com.example.isaachernandezquinonez.week3.db;

import android.content.ContentValues;
import android.content.Context;

import com.example.isaachernandezquinonez.week3.R;
import com.example.isaachernandezquinonez.week3.pojo.Mascota;

import java.util.ArrayList;

/**
 * Created by isaachernandezquinonez on 28/06/16.
 */
public class ConstructorMascotas {
    private static final Integer LIKES = 1;
    private Context context;
    public ConstructorMascotas(Context context){
        this.context = context;
    }
    public ArrayList<Mascota> obtenerDatos(){
       /*
        ArrayList<Mascota> mascotas = new ArrayList<Mascota>();
        mascotas.add(new Mascota(1,"Chester", R.drawable.cat,1));
        mascotas.add(new Mascota(1,"Daysi",R.drawable.clown_fish,2));
        mascotas.add(new Mascota(1,"Perry",R.drawable.cow,4));
        mascotas.add(new Mascota(1,"Bestia",R.drawable.duck,1));
        mascotas.add(new Mascota(1,"Corsar",R.drawable.frog,3));
        return mascotas;
       */
        BaseDatos db = new BaseDatos(context);
        insertarDiezMascotas(db);
        return db.obtenerTodosLosContactos();
    }
    public void insertarDiezMascotas(BaseDatos db){
        ContentValues contentValues = new ContentValues();

        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE, "Chester");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_FOTO, R.drawable.cat);
        db.insertarMascota(contentValues);

        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE, "Daysi");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_FOTO, R.drawable.clown_fish);
        db.insertarMascota(contentValues);

        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE, "Perry");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_FOTO, R.drawable.cow);
        db.insertarMascota(contentValues);

        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE, "Bestia");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_FOTO, R.drawable.duck);
        db.insertarMascota(contentValues);

        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE, "Frog");
        contentValues.put(ConstantesBaseDatos.TABLE_MASCOTAS_FOTO, R.drawable.giraffe);
        db.insertarMascota(contentValues);

    }

    public void darLikeMascota(Mascota mascota){
        BaseDatos db = new BaseDatos(context);
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_LIKES_MASCOTA_ID_MASCOTA,mascota.getId());
        contentValues.put(ConstantesBaseDatos.TABLE_LIKES_MASCOTA_NUMERO_LIKES,LIKES);
        db.insertarLikeMascota(contentValues);
    }

    public int obtenerLikesMascota(Mascota mascota){
        BaseDatos db = new BaseDatos(context);
        return db.obtenerLikesMascota(mascota);
    }
}
